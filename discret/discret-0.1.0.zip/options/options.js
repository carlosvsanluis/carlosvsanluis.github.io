const t = (key) => chrome.i18n.getMessage(key) || key;
const $ = (id) => document.getElementById(id);
const TYPES = ['email', 'phone', 'iban', 'card', 'nir'];
const DEFAULTS = {
  patterns: { email: true, phone: true, iban: true, card: true, nir: true },
  blur: 6, altClickCopy: true, maskSelectors: {}, extraSites: [],
};

document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });

function button(label, cls, onClick) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = cls;
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

async function load() {
  const s = await chrome.storage.sync.get(DEFAULTS);
  s.patterns = { ...DEFAULTS.patterns, ...s.patterns };

  // Sites
  const ul = $('sites');
  ul.querySelectorAll('li.extra').forEach((li) => li.remove());
  for (const origin of s.extraSites) {
    const li = document.createElement('li');
    li.className = 'extra';
    const code = document.createElement('code');
    code.textContent = origin.replace(/\/\*$/, '');
    li.append(code, button(t('optRemove'), 'link danger', () => removeSite(origin)));
    ul.appendChild(li);
  }

  // Detection
  const box = $('patterns');
  box.replaceChildren();
  for (const type of TYPES) {
    const label = document.createElement('label');
    label.className = 'check';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = s.patterns[type] !== false;
    cb.addEventListener('change', async () => {
      const { patterns } = await chrome.storage.sync.get(DEFAULTS);
      await chrome.storage.sync.set({ patterns: { ...DEFAULTS.patterns, ...patterns, [type]: cb.checked } });
    });
    const span = document.createElement('span');
    span.textContent = t(`type_${type}`);
    label.append(cb, span);
    box.appendChild(label);
  }
  $('blur').value = s.blur;
  $('blurVal').textContent = `${s.blur} px`;
  $('altClick').checked = s.altClickCopy;

  // Masked elements
  const masked = $('masked');
  masked.replaceChildren();
  const hosts = Object.keys(s.maskSelectors).filter((h) => s.maskSelectors[h].length);
  $('maskedEmpty').hidden = hosts.length > 0;
  for (const host of hosts) {
    const li = document.createElement('li');
    const b = document.createElement('b');
    b.textContent = host;
    const sels = document.createElement('div');
    sels.className = 'sels';
    for (const sel of s.maskSelectors[host]) {
      const row = document.createElement('div');
      row.className = 'sel';
      const code = document.createElement('code');
      code.textContent = sel;
      row.append(code, button(t('optRemove'), 'link danger', () => removeSelector(host, sel)));
      sels.appendChild(row);
    }
    li.append(b, sels);
    masked.appendChild(li);
  }
}

function message(text, ok) {
  const m = $('addMsg');
  m.textContent = text;
  m.className = `msg ${ok ? 'ok' : 'err'}`;
}

async function addSite(raw) {
  let url;
  try { url = new URL(/^https?:\/\//.test(raw) ? raw : `https://${raw}`); } catch { return message(t('optInvalidUrl'), false); }
  if (url.protocol !== 'https:') return message(t('optInvalidUrl'), false);
  const origin = `${url.origin}/*`;
  // Must run inside the click handler: the browser asks the user to grant access to this site only.
  const granted = await chrome.permissions.request({ origins: [origin] });
  if (!granted) return message(t('optPermissionDenied'), false);
  const { extraSites } = await chrome.storage.sync.get(DEFAULTS);
  if (!extraSites.includes(origin)) extraSites.push(origin);
  await chrome.storage.sync.set({ extraSites });
  await chrome.runtime.sendMessage({ type: 'discret:sync-sites' });
  $('addUrl').value = '';
  message(`${t('optSaved')} ${url.origin}`, true);
  load();
}

async function removeSite(origin) {
  const { extraSites } = await chrome.storage.sync.get(DEFAULTS);
  await chrome.storage.sync.set({ extraSites: extraSites.filter((o) => o !== origin) });
  await chrome.permissions.remove({ origins: [origin] }).catch(() => {});
  await chrome.runtime.sendMessage({ type: 'discret:sync-sites' });
  load();
}

async function removeSelector(host, sel) {
  const { maskSelectors } = await chrome.storage.sync.get(DEFAULTS);
  maskSelectors[host] = (maskSelectors[host] || []).filter((x) => x !== sel);
  if (!maskSelectors[host].length) delete maskSelectors[host];
  await chrome.storage.sync.set({ maskSelectors });
  load();
}

$('addForm').addEventListener('submit', (e) => { e.preventDefault(); addSite($('addUrl').value.trim()); });
$('blur').addEventListener('input', (e) => { $('blurVal').textContent = `${e.target.value} px`; });
$('blur').addEventListener('change', (e) => chrome.storage.sync.set({ blur: Number(e.target.value) }));
$('altClick').addEventListener('change', (e) => chrome.storage.sync.set({ altClickCopy: e.target.checked }));

chrome.commands.getAll().then((cmds) => {
  $('shortcut').textContent = cmds.find((c) => c.name === 'toggle-masking')?.shortcut || t('popupNoShortcut');
});
$('changeShortcut').addEventListener('click', () => {
  const page = navigator.userAgent.includes('Edg/') ? 'edge://extensions/shortcuts' : 'chrome://extensions/shortcuts';
  chrome.tabs.create({ url: page });
});

// Coming from the popup's "add this site" link: prefill the field.
const pre = new URLSearchParams(location.search).get('add');
if (pre) $('addUrl').value = pre;

chrome.storage.onChanged.addListener((_c, area) => { if (area === 'sync') load(); });
load();
