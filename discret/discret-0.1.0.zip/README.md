# Discret 0.1.0

**FR** · Extension pour Microsoft Edge et Google Chrome. Elle floute les données personnelles (e-mails, téléphones, IBAN, cartes bancaires, numéros de sécurité sociale) pendant un partage d'écran, et copie n'importe quelle valeur en un clic. Conçue pour Dynamics 365, elle fonctionne aussi sur d'autres applications web.

**EN** · Extension for Microsoft Edge and Google Chrome. It blurs personal data (e-mails, phone numbers, IBANs, card numbers, social security numbers) during screen sharing, and copies any value in one click. Built for Dynamics 365, it also works on other web apps.

---

## Installation (FR)

1. **Décompressez** le fichier zip : clic droit → *Extraire tout*. Vous obtenez un dossier qui contient `manifest.json`.
2. Dans Edge, ouvrez **`edge://extensions`** (Chrome : `chrome://extensions`).
3. Activez le **Mode développeur**.
4. Cliquez sur **Charger l'extension non empaquetée** et choisissez le dossier décompressé.
5. Épinglez Discret : icône puzzle dans la barre d'outils → épingle à côté de **Discret**.

## Utilisation (FR)

| Action | Résultat |
|---|---|
| **Alt + Maj + M** | Active ou désactive le masquage. Une pastille rouge « Masquage actif » apparaît. |
| Survoler un champ puis cliquer sur **⧉** | Copie la valeur, même masquée |
| **Alt + clic** sur un texte | Copie ce texte |
| Clic droit → **« Toujours masquer cet élément sur ce site »** | Masque ce bloc à chaque fois |
| Icône Discret | Interrupteur, copies récentes (masquées), lien vers les réglages |

Discret est actif sur **Dynamics 365** (`*.dynamics.com`) dès l'installation. Pour un autre site, ouvrez **Réglages → Sites**, saisissez l'adresse (https://…) puis cliquez sur **Ajouter**. Le navigateur demande l'autorisation pour ce site uniquement.

**Confidentialité :** rien ne quitte votre navigateur. Pas de serveur, pas de mesure d'audience. Les valeurs copiées restent en mémoire et s'effacent à la fermeture du navigateur.

**Désinstaller :** `edge://extensions` → Discret → **Supprimer**.

---

## Installation (EN)

1. **Unzip** the file: right-click → *Extract All*. You get a folder that contains `manifest.json`.
2. In Edge, open **`edge://extensions`** (Chrome: `chrome://extensions`).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the extracted folder.
5. Pin Discret: puzzle icon in the toolbar → pin next to **Discret**.

## How to use (EN)

| Action | Result |
|---|---|
| **Alt + Shift + M** | Turns masking on or off. A red "Masking on" pill appears. |
| Hover a field, then click **⧉** | Copies the value, even while masked |
| **Alt + click** on any text | Copies that text |
| Right-click → **"Always mask this element on this site"** | Masks that block every time |
| Discret icon | On/off switch, recent copies (masked), link to settings |

Discret runs on **Dynamics 365** (`*.dynamics.com`) as soon as it's installed. For another site, open **Settings → Sites**, enter its address (https://…) and click **Add**. The browser asks for permission for that site only.

**Privacy:** nothing leaves your browser. No server, no analytics. Copied values stay in memory and are erased when the browser closes.

**Uninstall:** `edge://extensions` → Discret → **Remove**.

---

© 2026 Carlos San Luis · https://carlosvsanluis.github.io · All rights reserved / tous droits réservés.
