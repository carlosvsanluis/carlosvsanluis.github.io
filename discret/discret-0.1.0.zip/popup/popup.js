const t = (key) => chrome.i18n.getMessage(key) || key;
const $ = (id) => document.getElementById(id);
let revealed = false;

document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });

$('options').addEventListener('click', () => chrome.runtime.openOptionsPage());

// Masking switch
chrome.storage.local.get({ masking: false }).then(({ masking }) => { $('masking').checked = masking; });
$('masking').addEventListener('change', (e) => chrome.storage.local.set({ masking: e.target.checked }));

chrome.commands.getAll().then((cmds) => {
  const c = cmds.find((x) => x.name === 'toggle-masking');
  $('shortcut').textContent = c?.shortcut || t('popupNoShortcut');
});

// Is Discret active on the current tab?
chrome.tabs.query({ active: true, currentWindow: true }).then(async ([tab]) => {
  if (!tab?.url || !/^https:/.test(tab.url)) return;
  const url = new URL(tab.url);
  const origin = `${url.origin}/*`;
  const on = /(^|\.)dynamics\.com$/.test(url.hostname) || (await chrome.permissions.contains({ origins: [origin] }));
  const box = $('site');
  box.classList.toggle('on', on);
  box.textContent = on ? t('popupSiteOn') : t('popupSiteOff');
  if (!on) {
    const add = document.createElement('button');
    add.className = 'link';
    add.textContent = t('popupAddSite');
    add.addEventListener('click', () => {
      chrome.tabs.create({ url: chrome.runtime.getURL(`options/options.html?add=${encodeURIComponent(url.origin)}`) });
    });
    box.appendChild(add);
  }
});

// Copy history (values are masked unless revealed: the popup may be visible on a shared screen)
const mask = (v) => (v.length <= 4 ? '••••' : `${v.slice(0, 2)}${'•'.repeat(Math.min(10, v.length - 4))}${v.slice(-2)}`);

async function renderHistory() {
  const { history = [] } = await chrome.storage.session.get({ history: [] });
  const ul = $('history');
  ul.replaceChildren();
  $('empty').hidden = history.length > 0;
  $('reveal').hidden = $('clear').hidden = history.length === 0;
  $('reveal').textContent = t(revealed ? 'popupHide' : 'popupReveal');
  for (const h of history) {
    const li = document.createElement('li');
    const b = document.createElement('button');
    const v = document.createElement('span'); v.className = 'v'; v.textContent = revealed ? h.value : mask(h.value);
    const k = document.createElement('span'); k.className = 'k'; k.textContent = h.kind ? t(`type_${h.kind}`) : t('value');
    const s = document.createElement('span'); s.className = 'h';
    s.textContent = `${h.host} · ${new Date(h.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    b.append(v, k, s);
    b.title = t('popupCopyAgain');
    b.addEventListener('click', async () => {
      await navigator.clipboard.writeText(h.value);
      k.textContent = `✓ ${t('copied')}`;
      k.classList.add('done');
      setTimeout(renderHistory, 1200);
    });
    li.appendChild(b);
    ul.appendChild(li);
  }
}

$('reveal').addEventListener('click', () => { revealed = !revealed; renderHistory(); });
$('clear').addEventListener('click', async () => { await chrome.storage.session.set({ history: [] }); renderHistory(); });
chrome.storage.onChanged.addListener((changes, area) => { if (area === 'session' && changes.history) renderHistory(); });
renderHistory();
