/*
 * Discret: background service worker.
 * Holds the masking switch (storage.local), the copy history (storage.session: memory only,
 * gone when the browser closes), the keyboard shortcut, the context menu and the extra sites.
 */
const HISTORY_MAX = 10;
const BUILTIN_MATCHES = ['https://*.dynamics.com/*'];
const MENU_ID = 'discret-mask-element';
const SCRIPT_ID = 'discret-extra-sites';

async function toggleMasking() {
  const { masking = false } = await chrome.storage.local.get('masking');
  await chrome.storage.local.set({ masking: !masking });
}

async function updateBadge() {
  const { masking = false } = await chrome.storage.local.get('masking');
  await chrome.action.setBadgeBackgroundColor({ color: '#c62828' });
  await chrome.action.setBadgeText({ text: masking ? 'ON' : '' });
  await chrome.action.setTitle({ title: chrome.i18n.getMessage(masking ? 'badgeOn' : 'badgeOff') });
}

async function grantedExtraSites() {
  const { extraSites = [] } = await chrome.storage.sync.get('extraSites');
  const granted = [];
  for (const origin of extraSites) {
    if (await chrome.permissions.contains({ origins: [origin] })) granted.push(origin);
  }
  return granted;
}

// Sites added by the user get the content script through dynamic registration.
async function syncExtraSites() {
  const matches = await grantedExtraSites();
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] });
  if (!matches.length) {
    if (existing.length) await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
  } else {
    const script = {
      id: SCRIPT_ID, matches, allFrames: true, runAt: 'document_idle', persistAcrossSessions: true,
      js: ['src/detect.js', 'src/content.js'], css: ['src/content.css'],
    };
    if (existing.length) await chrome.scripting.updateContentScripts([script]);
    else await chrome.scripting.registerContentScripts([script]);
  }
  await chrome.contextMenus.removeAll();
  chrome.contextMenus.create({
    id: MENU_ID,
    title: chrome.i18n.getMessage('menuMask'),
    contexts: ['all'],
    documentUrlPatterns: BUILTIN_MATCHES.concat(matches),
  });
}

chrome.runtime.onInstalled.addListener(() => { syncExtraSites(); updateBadge(); });
chrome.runtime.onStartup.addListener(() => { syncExtraSites(); updateBadge(); });

chrome.commands.onCommand.addListener((cmd) => { if (cmd === 'toggle-masking') toggleMasking(); });

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.masking) updateBadge();
  if (area === 'sync' && changes.extraSites) syncExtraSites();
});
chrome.permissions.onRemoved.addListener(() => syncExtraSites());

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === MENU_ID && tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: 'discret:mask-target' }, { frameId: info.frameId }).catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'discret:copied') {
    chrome.storage.session.get({ history: [] }).then(({ history }) => {
      history = history.filter((h) => h.value !== msg.value);
      history.unshift({ value: msg.value, kind: msg.kind || '', host: msg.host || '', at: Date.now() });
      chrome.storage.session.set({ history: history.slice(0, HISTORY_MAX) });
    });
  } else if (msg?.type === 'discret:sync-sites') {
    syncExtraSites().then(() => reply(true));
    return true;
  }
});
